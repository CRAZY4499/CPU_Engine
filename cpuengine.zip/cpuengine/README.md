# CPU Engine - Milestone 1 (proof of concept)

A 3D engine that renders ONLY on the CPU (no GPU, OpenGL, DirectX or Vulkan).

## What works in this milestone (tested)
- Software rasterizer: perspective-correct texturing, depth buffer, near-plane clipping, back-face culling
- Tile-based multi-threaded rendering (job system), plus a single-thread mode
- Frustum culling of objects, simple 2-level LOD, draw distance, fog
- Shading: unlit / flat / Gouraud; texture filtering: nearest / bilinear
- Render settings you can switch live: presets Low/Medium/High, resolution scale, rendering mode, threads,
  shading, filtering, textures, fog, back-face culling, LOD, frame-rate limit (30/60/none)
- Self-tests (13 checks) and a benchmark in `cpuengine_headless`

## NOT done yet (later milestones)
SIMD (SSE/AVX) pixel processing, ECS, physics, audio, the drag-and-drop editor, the visual
(no-code) logic system, model/texture import, and game export. The settings are currently
hotkeys, not yet an editor panel.

## Get the EXE
1. GitHub (no install needed): create a free repo, upload this whole folder, open the Actions tab,
   run "build-windows-exe", then download the `cpuengine-windows` artifact (contains cpuengine.exe).
2. Or on a Windows PC: install Visual Studio Build Tools or MSYS2 MinGW-w64, then run `build_windows.bat`.

## Controls (cpuengine.exe)
W A S D move, Q/E down/up, arrow keys look. 1/2/3 presets, R resolution, B render mode, T threads,
L shading, F filtering, X textures, G fog, C culling, O LOD, V frame limit, H HUD, Esc quit.

## Headless tool
cpuengine_headless --selftest | --bench 30 | --out frame.ppm [--mode single|tiled] [--scale 0.5]
