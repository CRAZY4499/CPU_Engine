#pragma once
// CPU-only 3D renderer: software rasterizer, tile-based, multi-threaded.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>

#include "jobs.h"
#include "math3d.h"

namespace ce {

// ---------------------------------------------------------------- settings
enum class RenderMode : int { SingleThread = 0, TiledMultiThread = 1 };
enum class ShadeMode : int { Unlit = 0, Flat = 1, Gouraud = 2 };

struct RenderSettings {
    RenderMode mode = RenderMode::TiledMultiThread;
    int threads = 0;                 // 0 = auto (all cores)
    float resolutionScale = 1.0f;    // internal resolution, 0.25 .. 1.0
    ShadeMode shading = ShadeMode::Gouraud;
    bool textures = true;
    bool bilinear = false;           // texture filtering
    bool backfaceCull = true;
    bool fog = false;
    bool lod = true;                 // swap to low-poly mesh at distance
    bool objectCulling = true;       // frustum culling of whole objects
    float drawDistance = 80.0f;
    int frameLimit = 60;             // 0 = unlimited (used by the app loop)
    int tileSize = 64;

    void validate() {
        resolutionScale = std::min(1.0f, std::max(0.25f, resolutionScale));
        drawDistance = std::min(500.0f, std::max(10.0f, drawDistance));
        tileSize = std::min(256, std::max(16, tileSize));
        if (threads < 0) threads = 0;
        if (threads > 64) threads = 64;
    }
    // 0 = Low, 1 = Medium, 2 = High
    static RenderSettings preset(int p) {
        RenderSettings s;
        if (p <= 0) {
            s.resolutionScale = 0.5f; s.shading = ShadeMode::Flat; s.bilinear = false;
            s.fog = true; s.drawDistance = 40; s.lod = true; s.frameLimit = 30;
        } else if (p == 1) {
            s.resolutionScale = 0.75f; s.shading = ShadeMode::Gouraud; s.bilinear = false;
            s.fog = false; s.drawDistance = 60; s.lod = true; s.frameLimit = 60;
        } else {
            s.resolutionScale = 1.0f; s.shading = ShadeMode::Gouraud; s.bilinear = true;
            s.fog = false; s.drawDistance = 100; s.lod = false; s.frameLimit = 60;
        }
        return s;
    }
};

// ----------------------------------------------------------------- assets
struct Texture {
    int w = 0, h = 0;            // must be powers of two
    std::vector<uint32_t> px;    // 0x00RRGGBB

    uint32_t nearest(float u, float v) const {
        int x = (int)std::floor(u * (float)w) & (w - 1);
        int y = (int)std::floor(v * (float)h) & (h - 1);
        return px[(size_t)y * w + x];
    }
    uint32_t bilinear(float u, float v) const {
        float fx = u * (float)w - 0.5f, fy = v * (float)h - 0.5f;
        float flx = std::floor(fx), fly = std::floor(fy);
        int x0 = (int)flx, y0 = (int)fly;
        int ax = (int)((fx - flx) * 256.0f), ay = (int)((fy - fly) * 256.0f);
        int x1 = (x0 + 1) & (w - 1), y1 = (y0 + 1) & (h - 1);
        x0 &= (w - 1);
        y0 &= (h - 1);
        uint32_t c00 = px[(size_t)y0 * w + x0], c10 = px[(size_t)y0 * w + x1];
        uint32_t c01 = px[(size_t)y1 * w + x0], c11 = px[(size_t)y1 * w + x1];
        uint32_t out = 0;
        for (int sh = 0; sh <= 16; sh += 8) {
            int a = (c00 >> sh) & 255, b = (c10 >> sh) & 255;
            int c = (c01 >> sh) & 255, d = (c11 >> sh) & 255;
            int top = a * (256 - ax) + b * ax;
            int bot = c * (256 - ax) + d * ax;
            int v8 = (top * (256 - ay) + bot * ay) >> 16;
            out |= (uint32_t)v8 << sh;
        }
        return out;
    }
};

struct Vertex {
    Vec3 pos, normal;
    float u = 0, v = 0;
};

struct Mesh {
    std::vector<Vertex> verts;
    std::vector<uint32_t> idx;  // triangle list, counter-clockwise = front face
    float radius = 0;           // bounding sphere radius around the origin
    void finalize() {
        radius = 0;
        for (auto& v : verts) radius = std::max(radius, length(v.pos));
    }
    int triCount() const { return (int)idx.size() / 3; }
};

struct Instance {
    const Mesh* mesh = nullptr;
    const Mesh* lodMesh = nullptr;  // optional lower-detail mesh
    float lodDistance = 25.0f;
    Mat4 model = Mat4::identity();
    float scale = 1.0f;             // uniform scale contained in `model`
    Vec3 tint{1, 1, 1};
    const Texture* tex = nullptr;
};

struct Camera {
    Vec3 pos{0, 2, 10};
    float yaw = 0;      // 0 looks down -Z
    float pitch = 0;
    float fovy = 1.2f;  // radians
};

inline Vec3 cameraForward(const Camera& c) {
    float cp = std::cos(c.pitch);
    return {std::sin(c.yaw) * cp, std::sin(c.pitch), -std::cos(c.yaw) * cp};
}
inline Vec3 cameraRight(const Camera& c) { return {std::cos(c.yaw), 0, std::sin(c.yaw)}; }

struct Stats {
    int objectsTotal = 0, objectsCulled = 0;
    int trisSubmitted = 0, trisDrawn = 0;
    int threads = 1;
    double msVertex = 0, msBin = 0, msRaster = 0, msTotal = 0;
};

namespace detail {
struct ScreenTri {
    float x[3], y[3], z[3], iw[3], uw[3], vw[3], sh[3];
    float invArea;
    int minx, miny, maxx, maxy;
    int tintR, tintG, tintB;  // 0..256
    const Texture* tex;
};
struct ClipVert { float x, y, z, w, u, v, shade; };
}  // namespace detail

// -------------------------------------------------------------- renderer
class Renderer {
public:
    Renderer() = default;
    // Internal render target = window size * scale.
    void setTarget(int windowW, int windowH, float scale);
    void render(const std::vector<Instance>& scene, const Camera& cam, const RenderSettings& s);

    int width() const { return W_; }
    int height() const { return H_; }
    const uint32_t* pixels() const { return color_.data(); }  // 0x00RRGGBB
    const Stats& stats() const { return stats_; }

private:
    void rasterTile(int tileIdx, const RenderSettings& s);

    int W_ = 0, H_ = 0, tilesX_ = 0, tilesY_ = 0, tileSize_ = 64;
    std::vector<uint32_t> color_;
    std::vector<float> depth_;
    std::unique_ptr<ThreadPool> pool_;
    std::vector<std::vector<detail::ScreenTri>> instTris_;
    std::vector<char> culled_;
    std::vector<detail::ScreenTri> tris_;
    std::vector<std::vector<uint32_t>> tileTris_;
    Stats stats_;
};

}  // namespace ce
