#pragma once
// Small job system: parallelFor() splits work across worker threads.
// The calling thread also works, so ThreadPool(n) gives n-way parallelism.
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>

namespace ce {

class ThreadPool {
public:
    explicit ThreadPool(int totalThreads) : total_(totalThreads < 1 ? 1 : totalThreads) {
        for (int i = 1; i < total_; i++) workers_.emplace_back([this] { workerMain(); });
    }
    ~ThreadPool() {
        {
            std::lock_guard<std::mutex> lk(m_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& t : workers_) t.join();
    }
    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

    int size() const { return total_; }

    void parallelFor(int count, const std::function<void(int)>& fn) {
        if (workers_.empty() || count <= 1) {
            for (int i = 0; i < count; i++) fn(i);
            return;
        }
        {
            std::lock_guard<std::mutex> lk(m_);
            job_ = &fn;
            count_ = count;
            next_.store(0);
            pending_ = (int)workers_.size();
            ++generation_;
        }
        cv_.notify_all();
        runLoop(fn, count);
        std::unique_lock<std::mutex> lk(m_);
        cvDone_.wait(lk, [&] { return pending_ == 0; });
        job_ = nullptr;
    }

private:
    void runLoop(const std::function<void(int)>& fn, int count) {
        for (;;) {
            int i = next_.fetch_add(1);
            if (i >= count) break;
            fn(i);
        }
    }
    void workerMain() {
        uint64_t seen = 0;
        for (;;) {
            const std::function<void(int)>* j;
            int c;
            {
                std::unique_lock<std::mutex> lk(m_);
                cv_.wait(lk, [&] { return stop_ || generation_ != seen; });
                if (stop_) return;
                seen = generation_;
                j = job_;
                c = count_;
            }
            runLoop(*j, c);
            {
                std::lock_guard<std::mutex> lk(m_);
                if (--pending_ == 0) cvDone_.notify_one();
            }
        }
    }

    int total_;
    std::vector<std::thread> workers_;
    std::mutex m_;
    std::condition_variable cv_, cvDone_;
    const std::function<void(int)>* job_ = nullptr;
    std::atomic<int> next_{0};
    int count_ = 0;
    int pending_ = 0;
    uint64_t generation_ = 0;
    bool stop_ = false;
};

}  // namespace ce
