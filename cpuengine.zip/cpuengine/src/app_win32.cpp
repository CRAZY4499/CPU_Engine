// Windows front-end for the CPU engine. Uses only Win32 + GDI (no GPU, no DirectX/OpenGL).
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>

#include <cstdio>
#include <cstring>
#include <exception>
#include <thread>
#include <vector>

#include "renderer.h"
#include "scene.h"

#ifdef _MSC_VER
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#endif

using namespace ce;

static Renderer g_renderer;
static RenderSettings g_settings = RenderSettings::preset(1);
static Camera g_cam;
static int g_winW = 960, g_winH = 540;
static bool g_running = true, g_hud = true;
static int g_preset = 1;
static const char* g_exitReason = "unknown";
static void logLine(const char* msg, bool fresh = false) {
    FILE* f = std::fopen("cpuengine_log.txt", fresh ? "w" : "a");
    if (f) { std::fprintf(f, "%s\n", msg); std::fclose(f); }
}
static std::vector<int> g_threadSteps;
static size_t g_threadIdx = 0;

static void cycleThreads() {
    g_threadIdx = (g_threadIdx + 1) % g_threadSteps.size();
    g_settings.threads = g_threadSteps[g_threadIdx];
}

static void applyPreset(int p) {
    g_preset = p;
    g_settings = RenderSettings::preset(p);
    g_settings.threads = g_threadSteps[g_threadIdx];
}

static void onKey(int vk) {
    switch (vk) {
        case VK_ESCAPE: g_exitReason = "Esc key pressed"; g_running = false; break;
        case '1': applyPreset(0); break;
        case '2': applyPreset(1); break;
        case '3': applyPreset(2); break;
        case 'R': {  // resolution scale 50 -> 75 -> 100 -> 50
            float& r = g_settings.resolutionScale;
            r = (r < 0.6f) ? 0.75f : (r < 0.9f ? 1.0f : 0.5f);
            break;
        }
        case 'T': cycleThreads(); break;
        case 'B':
            g_settings.mode = g_settings.mode == RenderMode::SingleThread ? RenderMode::TiledMultiThread
                                                                           : RenderMode::SingleThread;
            break;
        case 'L': g_settings.shading = (ShadeMode)(((int)g_settings.shading + 1) % 3); break;
        case 'F': g_settings.bilinear = !g_settings.bilinear; break;
        case 'X': g_settings.textures = !g_settings.textures; break;
        case 'G': g_settings.fog = !g_settings.fog; break;
        case 'C': g_settings.backfaceCull = !g_settings.backfaceCull; break;
        case 'O': g_settings.lod = !g_settings.lod; break;
        case 'V': g_settings.frameLimit = g_settings.frameLimit == 30 ? 60 : (g_settings.frameLimit == 60 ? 0 : 30); break;
        case 'H': g_hud = !g_hud; break;
        default: break;
    }
}

static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
        case WM_CLOSE:
        case WM_DESTROY:
            g_exitReason = (m == WM_CLOSE) ? "window closed (WM_CLOSE)" : "window destroyed (WM_DESTROY)";
            g_running = false;
            PostQuitMessage(0);
            return 0;
        case WM_SIZE:
            g_winW = LOWORD(l);
            g_winH = HIWORD(l);
            return 0;
        case WM_KEYDOWN:
            if (!(l & (1 << 30))) onKey((int)w);  // ignore auto-repeat
            return 0;
        case WM_ERASEBKGND:
            return 1;
        default:
            break;
    }
    return DefWindowProcA(h, m, w, l);
}

static const char* shadeName(ShadeMode s) {
    return s == ShadeMode::Unlit ? "Unlit" : (s == ShadeMode::Flat ? "Flat" : "Gouraud");
}

static void drawHud(HDC dc, double fps, const Stats& st) {
    char lines[12][160];
    int n = 0;
    std::snprintf(lines[n++], 160, "CPU Engine M1 | FPS %.0f | frame %.1f ms (vertex %.1f, bin %.1f, raster %.1f)", fps,
                  st.msTotal, st.msVertex, st.msBin, st.msRaster);
    std::snprintf(lines[n++], 160, "Internal %dx%d | tris %d/%d | objects culled %d/%d | threads %d", g_renderer.width(),
                  g_renderer.height(), st.trisDrawn, st.trisSubmitted, st.objectsCulled, st.objectsTotal, st.threads);
    std::snprintf(lines[n++], 160, "[1/2/3] preset Low/Med/High   [R] res %d%%   [B] mode %s   [T] threads %s%d",
                  (int)(g_settings.resolutionScale * 100 + 0.5f),
                  g_settings.mode == RenderMode::SingleThread ? "single" : "tiled-MT",
                  g_settings.threads == 0 ? "auto/" : "", g_settings.threads == 0 ? st.threads : g_settings.threads);
    std::snprintf(lines[n++], 160, "[L] shading %s   [F] filter %s   [X] textures %s   [G] fog %s", shadeName(g_settings.shading),
                  g_settings.bilinear ? "bilinear" : "nearest", g_settings.textures ? "on" : "off", g_settings.fog ? "on" : "off");
    std::snprintf(lines[n++], 160, "[C] backface cull %s   [O] LOD %s   [V] frame limit %s   [H] hide HUD   [Esc] quit",
                  g_settings.backfaceCull ? "on" : "off", g_settings.lod ? "on" : "off",
                  g_settings.frameLimit == 0 ? "none" : (g_settings.frameLimit == 30 ? "30" : "60"));
    std::snprintf(lines[n++], 160, "Move: W A S D, Q/E up/down   Look: arrow keys");
    SetBkMode(dc, TRANSPARENT);
    for (int i = 0; i < n; i++) {
        int len = (int)std::strlen(lines[i]);
        SetTextColor(dc, RGB(0, 0, 0));
        TextOutA(dc, 11, 9 + i * 16, lines[i], len);
        SetTextColor(dc, RGB(255, 255, 255));
        TextOutA(dc, 10, 8 + i * 16, lines[i], len);
    }
}

static int runApp(HINSTANCE hInst) {
    logLine("CPU Engine starting", true);
    timeBeginPeriod(1);

    unsigned hw = std::thread::hardware_concurrency();
    if (hw == 0) hw = 1;
    g_threadSteps = {0, 1, 2, 4};
    if (hw > 4) g_threadSteps.push_back((int)hw);
    applyPreset(1);

    g_cam.pos = {0, 6, 22};
    g_cam.pitch = -0.2f;
    SceneAssets assets;
    std::vector<Instance> scene;

    WNDCLASSA wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = "CpuEngineWindow";
    RegisterClassA(&wc);
    RECT rc = {0, 0, g_winW, g_winH};
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);
    HWND hwnd = CreateWindowA(wc.lpszClassName, "CPU Engine - Milestone 1", WS_OVERLAPPEDWINDOW | WS_VISIBLE,
                              CW_USEDEFAULT, CW_USEDEFAULT, rc.right - rc.left, rc.bottom - rc.top, nullptr, nullptr,
                              hInst, nullptr);
    if (!hwnd) {
        logLine("CreateWindow failed");
        MessageBoxA(nullptr, "Could not create the window.", "CPU Engine", MB_OK | MB_ICONERROR);
        return 1;
    }
    logLine("window created");

    LARGE_INTEGER freq, last, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&last);
    double sceneTime = 0, fps = 0;

    while (g_running) {
        MSG msg;
        while (PeekMessageA(&msg, nullptr, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) { g_exitReason = "WM_QUIT received"; g_running = false; }
            TranslateMessage(&msg);
            DispatchMessageA(&msg);
        }
        if (!g_running) break;
        if (g_winW <= 0 || g_winH <= 0) { Sleep(30); continue; }  // minimized

        QueryPerformanceCounter(&now);
        double dt = (double)(now.QuadPart - last.QuadPart) / (double)freq.QuadPart;
        last = now;
        if (dt > 0.25) dt = 0.25;
        sceneTime += dt;
        fps = fps * 0.9 + (dt > 0 ? 1.0 / dt : 0) * 0.1;

        if (GetForegroundWindow() == hwnd) {
            auto down = [](int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; };
            float sp = 8.0f * (float)dt, tr = 1.6f * (float)dt;
            Vec3 f = cameraForward(g_cam), r = cameraRight(g_cam);
            if (down('W')) g_cam.pos = g_cam.pos + f * sp;
            if (down('S')) g_cam.pos = g_cam.pos - f * sp;
            if (down('D')) g_cam.pos = g_cam.pos + r * sp;
            if (down('A')) g_cam.pos = g_cam.pos - r * sp;
            if (down('E')) g_cam.pos.y += sp;
            if (down('Q')) g_cam.pos.y -= sp;
            if (down(VK_LEFT)) g_cam.yaw -= tr;
            if (down(VK_RIGHT)) g_cam.yaw += tr;
            if (down(VK_UP)) g_cam.pitch += tr;
            if (down(VK_DOWN)) g_cam.pitch -= tr;
            if (g_cam.pitch > 1.5f) g_cam.pitch = 1.5f;
            if (g_cam.pitch < -1.5f) g_cam.pitch = -1.5f;
            if (g_cam.pos.y < 0.3f) g_cam.pos.y = 0.3f;
        }

        g_settings.validate();
        buildDemoScene(assets, 10, (float)sceneTime, scene);
        g_renderer.setTarget(g_winW, g_winH, g_settings.resolutionScale);
        g_renderer.render(scene, g_cam, g_settings);

        HDC dc = GetDC(hwnd);
        BITMAPINFO bmi = {};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = g_renderer.width();
        bmi.bmiHeader.biHeight = -g_renderer.height();  // top-down
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;
        StretchDIBits(dc, 0, 0, g_winW, g_winH, 0, 0, g_renderer.width(), g_renderer.height(), g_renderer.pixels(), &bmi,
                      DIB_RGB_COLORS, SRCCOPY);
        if (g_hud) drawHud(dc, fps, g_renderer.stats());
        ReleaseDC(hwnd, dc);
        static bool firstFrameLogged = false;
        if (!firstFrameLogged) {
            firstFrameLogged = true;
            char b[160];
            std::snprintf(b, sizeof b, "first frame rendered OK: %dx%d internal, %d threads", g_renderer.width(),
                          g_renderer.height(), g_renderer.stats().threads);
            logLine(b);
        }

        if (g_settings.frameLimit > 0) {  // sleep instead of burning CPU
            QueryPerformanceCounter(&now);
            double spent = (double)(now.QuadPart - last.QuadPart) * 1000.0 / (double)freq.QuadPart;
            double target = 1000.0 / (double)g_settings.frameLimit;
            if (spent < target) Sleep((DWORD)(target - spent));
        }
    }
    timeEndPeriod(1);
    char b[160];
    std::snprintf(b, sizeof b, "exit reason: %s", g_exitReason);
    logLine(b);
    return 0;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int) {
    try {
        return runApp(hInst);
    } catch (const std::exception& e) {
        logLine(e.what());
        MessageBoxA(nullptr, e.what(), "CPU Engine error", MB_OK | MB_ICONERROR);
    } catch (...) {
        logLine("unknown error");
        MessageBoxA(nullptr, "Unknown error", "CPU Engine error", MB_OK | MB_ICONERROR);
    }
    return 1;
}
