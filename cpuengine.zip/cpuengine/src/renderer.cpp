#include "renderer.h"

#include <chrono>
#include <thread>

namespace ce {

using detail::ClipVert;
using detail::ScreenTri;

static const float kAmbient = 0.25f;
static const Vec3 kLightDir = {0.4f, 1.0f, 0.3f};  // direction TOWARD the light

static inline uint32_t skyColor(int y, int H) {
    float t = (float)y / (float)(H > 1 ? H - 1 : 1);
    int r = (int)(90 + (200 - 90) * t), g = (int)(140 + (225 - 140) * t), b = (int)(220 + (245 - 220) * t);
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

void Renderer::setTarget(int windowW, int windowH, float scale) {
    scale = std::min(1.0f, std::max(0.25f, scale));
    int w = std::max(16, (int)((float)windowW * scale));
    int h = std::max(16, (int)((float)windowH * scale));
    if (w == W_ && h == H_) return;
    W_ = w;
    H_ = h;
    color_.assign((size_t)W_ * H_, 0);
    depth_.assign((size_t)W_ * H_, 1.0f);
}

static inline ClipVert lerpVert(const ClipVert& a, const ClipVert& b, float t) {
    ClipVert r;
    r.x = a.x + (b.x - a.x) * t;
    r.y = a.y + (b.y - a.y) * t;
    r.z = a.z + (b.z - a.z) * t;
    r.w = a.w + (b.w - a.w) * t;
    r.u = a.u + (b.u - a.u) * t;
    r.v = a.v + (b.v - a.v) * t;
    r.shade = a.shade + (b.shade - a.shade) * t;
    return r;
}

// Clip a triangle against the near plane (z + w >= 0). Returns 0, 3 or 4 vertices.
static int clipNear(const ClipVert in[3], ClipVert out[4]) {
    int n = 0;
    for (int i = 0; i < 3; i++) {
        const ClipVert& a = in[i];
        const ClipVert& b = in[(i + 1) % 3];
        float da = a.z + a.w, db = b.z + b.w;
        if (da >= 0) out[n++] = a;
        if ((da >= 0) != (db >= 0)) out[n++] = lerpVert(a, b, da / (da - db));
    }
    return n;
}

void Renderer::render(const std::vector<Instance>& scene, const Camera& cam, const RenderSettings& sIn) {
    using clock = std::chrono::steady_clock;
    auto ms = [](clock::time_point a, clock::time_point b) {
        return std::chrono::duration<double, std::milli>(b - a).count();
    };
    auto t0 = clock::now();
    RenderSettings s = sIn;
    s.validate();

    int want = 1;
    if (s.mode == RenderMode::TiledMultiThread)
        want = s.threads > 0 ? s.threads : (int)std::max(1u, std::thread::hardware_concurrency());
    if (!pool_ || pool_->size() != want) pool_.reset(new ThreadPool(want));
    stats_ = Stats();
    stats_.threads = pool_->size();
    stats_.objectsTotal = (int)scene.size();

    if (W_ <= 0 || H_ <= 0) return;
    const int W = W_, H = H_;
    tileSize_ = s.tileSize;
    tilesX_ = (W + tileSize_ - 1) / tileSize_;
    tilesY_ = (H + tileSize_ - 1) / tileSize_;

    const float aspect = (float)W / (float)H;
    const float nearZ = 0.1f;
    Mat4 proj = perspective(cam.fovy, aspect, nearZ, s.drawDistance);
    Vec3 fwd = cameraForward(cam);
    Mat4 view = lookAt(cam.pos, cam.pos + fwd, {0, 1, 0});
    Mat4 vp = proj * view;
    Vec3 Lw = normalize(kLightDir);

    // Frustum side planes in view space (inward normals).
    float halfH = std::tan(cam.fovy * 0.5f), halfW = halfH * aspect;
    float nx = 1.0f / std::sqrt(1.0f + halfW * halfW), ny = 1.0f / std::sqrt(1.0f + halfH * halfH);
    Vec3 pL{nx, 0, -halfW * nx}, pR{-nx, 0, -halfW * nx}, pT{0, -ny, -halfH * ny}, pB{0, ny, -halfH * ny};

    instTris_.resize(scene.size());
    culled_.assign(scene.size(), 0);

    // ---------------------------------------------------- vertex stage
    auto vertexJob = [&](int idx) {
        auto& out = instTris_[idx];
        out.clear();
        const Instance& in = scene[idx];
        if (!in.mesh) return;
        Vec3 vc = transformPoint(view, transformPoint(in.model, {0, 0, 0}));
        float r = in.mesh->radius * in.scale;
        if (s.objectCulling) {
            float depth = -vc.z;
            if (depth + r < nearZ || depth - r > s.drawDistance || dot(pL, vc) < -r || dot(pR, vc) < -r ||
                dot(pT, vc) < -r || dot(pB, vc) < -r) {
                culled_[idx] = 1;
                return;
            }
        }
        const Mesh* mesh = in.mesh;
        if (s.lod && in.lodMesh && length(vc) > in.lodDistance) mesh = in.lodMesh;

        thread_local std::vector<ClipVert> cv;
        cv.resize(mesh->verts.size());
        Mat4 mvp = vp * in.model;
        for (size_t k = 0; k < mesh->verts.size(); k++) {
            const Vertex& v = mesh->verts[k];
            ClipVert& c = cv[k];
            c.x = mvp.m[0][0] * v.pos.x + mvp.m[0][1] * v.pos.y + mvp.m[0][2] * v.pos.z + mvp.m[0][3];
            c.y = mvp.m[1][0] * v.pos.x + mvp.m[1][1] * v.pos.y + mvp.m[1][2] * v.pos.z + mvp.m[1][3];
            c.z = mvp.m[2][0] * v.pos.x + mvp.m[2][1] * v.pos.y + mvp.m[2][2] * v.pos.z + mvp.m[2][3];
            c.w = mvp.m[3][0] * v.pos.x + mvp.m[3][1] * v.pos.y + mvp.m[3][2] * v.pos.z + mvp.m[3][3];
            c.u = v.u;
            c.v = v.v;
            if (s.shading == ShadeMode::Unlit) {
                c.shade = 1.0f;
            } else {
                Vec3 n = normalize(transformDir(in.model, v.normal));
                float d = std::max(0.0f, dot(n, Lw));
                c.shade = kAmbient + (1.0f - kAmbient) * d;
            }
        }
        const int tintR = (int)(std::min(1.0f, std::max(0.0f, in.tint.x)) * 256.0f);
        const int tintG = (int)(std::min(1.0f, std::max(0.0f, in.tint.y)) * 256.0f);
        const int tintB = (int)(std::min(1.0f, std::max(0.0f, in.tint.z)) * 256.0f);

        auto emit = [&](const ClipVert& a, const ClipVert& b, const ClipVert& c) {
            const ClipVert* cvs[3] = {&a, &b, &c};
            ScreenTri t;
            for (int k = 0; k < 3; k++) {
                const ClipVert& q = *cvs[k];
                float iw = 1.0f / q.w;
                t.x[k] = (q.x * iw * 0.5f + 0.5f) * (float)W;
                t.y[k] = (1.0f - (q.y * iw * 0.5f + 0.5f)) * (float)H;
                t.z[k] = q.z * iw;
                t.iw[k] = iw;
                t.uw[k] = q.u * iw;
                t.vw[k] = q.v * iw;
                t.sh[k] = q.shade;
            }
            float area = (t.x[1] - t.x[0]) * (t.y[2] - t.y[0]) - (t.y[1] - t.y[0]) * (t.x[2] - t.x[0]);
            if (area > 0) {  // back face (front faces have negative screen-space area)
                if (s.backfaceCull) return;
                std::swap(t.x[1], t.x[2]); std::swap(t.y[1], t.y[2]); std::swap(t.z[1], t.z[2]);
                std::swap(t.iw[1], t.iw[2]); std::swap(t.uw[1], t.uw[2]); std::swap(t.vw[1], t.vw[2]);
                std::swap(t.sh[1], t.sh[2]);
                area = -area;
            }
            if (area > -1e-5f) return;  // degenerate
            if (std::min(t.z[0], std::min(t.z[1], t.z[2])) > 1.0f) return;  // beyond far plane
            float fminx = std::min(t.x[0], std::min(t.x[1], t.x[2]));
            float fmaxx = std::max(t.x[0], std::max(t.x[1], t.x[2]));
            float fminy = std::min(t.y[0], std::min(t.y[1], t.y[2]));
            float fmaxy = std::max(t.y[0], std::max(t.y[1], t.y[2]));
            if (fmaxx < 0 || fmaxy < 0 || fminx > (float)W || fminy > (float)H) return;
            t.minx = std::max(0, (int)std::floor(fminx));
            t.maxx = std::min(W - 1, (int)std::ceil(fmaxx));
            t.miny = std::max(0, (int)std::floor(fminy));
            t.maxy = std::min(H - 1, (int)std::ceil(fmaxy));
            if (t.maxx < t.minx || t.maxy < t.miny) return;
            if (s.shading == ShadeMode::Flat) {
                float f = (t.sh[0] + t.sh[1] + t.sh[2]) * (1.0f / 3.0f);
                t.sh[0] = t.sh[1] = t.sh[2] = f;
            }
            t.invArea = 1.0f / area;
            t.tintR = tintR; t.tintG = tintG; t.tintB = tintB;
            t.tex = in.tex;
            out.push_back(t);
        };

        for (size_t i = 0; i + 2 < mesh->idx.size(); i += 3) {
            ClipVert tri[3] = {cv[mesh->idx[i]], cv[mesh->idx[i + 1]], cv[mesh->idx[i + 2]]};
            float d0 = tri[0].z + tri[0].w, d1 = tri[1].z + tri[1].w, d2 = tri[2].z + tri[2].w;
            if (d0 < 0 && d1 < 0 && d2 < 0) continue;
            if (d0 >= 0 && d1 >= 0 && d2 >= 0) {
                emit(tri[0], tri[1], tri[2]);
            } else {
                ClipVert poly[4];
                int n = clipNear(tri, poly);
                for (int k = 1; k + 1 < n; k++) emit(poly[0], poly[k], poly[k + 1]);
            }
        }
    };

    int totalSubmitted = 0;
    pool_->parallelFor((int)scene.size(), vertexJob);
    auto t1 = clock::now();

    // ------------------------------------------------------ bin tris
    tris_.clear();
    for (size_t i = 0; i < scene.size(); i++) {
        if (culled_[i]) { stats_.objectsCulled++; continue; }
        if (scene[i].mesh) totalSubmitted += scene[i].mesh->triCount();
        tris_.insert(tris_.end(), instTris_[i].begin(), instTris_[i].end());
    }
    const int numTiles = tilesX_ * tilesY_;
    tileTris_.resize(numTiles);
    for (auto& v : tileTris_) v.clear();
    for (uint32_t ti = 0; ti < (uint32_t)tris_.size(); ti++) {
        const ScreenTri& t = tris_[ti];
        int tx0 = t.minx / tileSize_, tx1 = t.maxx / tileSize_;
        int ty0 = t.miny / tileSize_, ty1 = t.maxy / tileSize_;
        for (int ty = ty0; ty <= ty1; ty++)
            for (int tx = tx0; tx <= tx1; tx++) tileTris_[(size_t)ty * tilesX_ + tx].push_back(ti);
    }
    stats_.trisSubmitted = totalSubmitted;
    stats_.trisDrawn = (int)tris_.size();
    auto t2 = clock::now();

    // ---------------------------------------------- raster (per tile)
    pool_->parallelFor(numTiles, [&](int i) { rasterTile(i, s); });
    auto t3 = clock::now();

    stats_.msVertex = ms(t0, t1);
    stats_.msBin = ms(t1, t2);
    stats_.msRaster = ms(t2, t3);
    stats_.msTotal = ms(t0, t3);
}

void Renderer::rasterTile(int tileIdx, const RenderSettings& s) {
    const int T = tileSize_;
    const int tx = tileIdx % tilesX_, ty = tileIdx / tilesX_;
    const int x0 = tx * T, y0 = ty * T;
    const int x1 = std::min(x0 + T, W_) - 1, y1 = std::min(y0 + T, H_) - 1;

    for (int y = y0; y <= y1; y++) {
        uint32_t sky = skyColor(y, H_);
        uint32_t* crow = &color_[(size_t)y * W_];
        float* drow = &depth_[(size_t)y * W_];
        for (int x = x0; x <= x1; x++) { crow[x] = sky; drow[x] = 1.0f; }
    }

    const bool useFog = s.fog;
    const float fogStart = s.drawDistance * 0.35f;
    const float fogInv = 1.0f / std::max(1.0f, s.drawDistance * 0.65f);
    const uint32_t fogCol = skyColor(H_ - 1, H_);
    const int fogR = (fogCol >> 16) & 255, fogG = (fogCol >> 8) & 255, fogB = fogCol & 255;
    const bool bilinear = s.bilinear;

    auto edge = [](float ax, float ay, float bx, float by, float px, float py) {
        return (bx - ax) * (py - ay) - (by - ay) * (px - ax);
    };

    for (uint32_t ti : tileTris_[tileIdx]) {
        const ScreenTri& t = tris_[ti];
        const int bx0 = std::max(t.minx, x0), bx1 = std::min(t.maxx, x1);
        const int by0 = std::max(t.miny, y0), by1 = std::min(t.maxy, y1);
        if (bx1 < bx0 || by1 < by0) continue;
        const bool useTex = s.textures && t.tex != nullptr;

        const float dw0dx = t.y[1] - t.y[2], dw0dy = t.x[2] - t.x[1];
        const float dw1dx = t.y[2] - t.y[0], dw1dy = t.x[0] - t.x[2];
        const float dw2dx = t.y[0] - t.y[1], dw2dy = t.x[1] - t.x[0];
        const float px = (float)bx0 + 0.5f, py = (float)by0 + 0.5f;
        float r0 = edge(t.x[1], t.y[1], t.x[2], t.y[2], px, py);
        float r1 = edge(t.x[2], t.y[2], t.x[0], t.y[0], px, py);
        float r2 = edge(t.x[0], t.y[0], t.x[1], t.y[1], px, py);

        for (int y = by0; y <= by1; y++, r0 += dw0dy, r1 += dw1dy, r2 += dw2dy) {
            float w0 = r0, w1 = r1, w2 = r2;
            uint32_t* crow = &color_[(size_t)y * W_];
            float* drow = &depth_[(size_t)y * W_];
            for (int x = bx0; x <= bx1; x++, w0 += dw0dx, w1 += dw1dx, w2 += dw2dx) {
                if (!((w0 <= 0.0f) & (w1 <= 0.0f) & (w2 <= 0.0f))) continue;
                float b0 = w0 * t.invArea, b1 = w1 * t.invArea, b2 = w2 * t.invArea;
                float z = b0 * t.z[0] + b1 * t.z[1] + b2 * t.z[2];
                if (!(z < drow[x])) continue;
                float rw = 1.0f / (b0 * t.iw[0] + b1 * t.iw[1] + b2 * t.iw[2]);
                int shade = (int)((b0 * t.sh[0] + b1 * t.sh[1] + b2 * t.sh[2]) * 256.0f);
                shade = shade < 0 ? 0 : (shade > 256 ? 256 : shade);
                uint32_t texel = 0x00FFFFFFu;
                if (useTex) {
                    float u = (b0 * t.uw[0] + b1 * t.uw[1] + b2 * t.uw[2]) * rw;
                    float v = (b0 * t.vw[0] + b1 * t.vw[1] + b2 * t.vw[2]) * rw;
                    texel = bilinear ? t.tex->bilinear(u, v) : t.tex->nearest(u, v);
                }
                int r = ((((texel >> 16) & 255) * t.tintR) >> 8) * shade >> 8;
                int g = ((((texel >> 8) & 255) * t.tintG) >> 8) * shade >> 8;
                int b = (((texel & 255) * t.tintB) >> 8) * shade >> 8;
                if (useFog) {
                    float f = (rw - fogStart) * fogInv;
                    int fi = f <= 0 ? 0 : (f >= 1 ? 256 : (int)(f * 256.0f));
                    r += ((fogR - r) * fi) >> 8;
                    g += ((fogG - g) * fi) >> 8;
                    b += ((fogB - b) * fi) >> 8;
                }
                drow[x] = z;
                crow[x] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
            }
        }
    }
}

}  // namespace ce
