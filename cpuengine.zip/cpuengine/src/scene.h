#pragma once
// Procedural meshes/textures and the demo scene (no external asset files needed).
#include <cmath>
#include <vector>

#include "renderer.h"

namespace ce {

inline Mesh makeCube() {
    Mesh m;
    struct Face { Vec3 n, u, v; };
    const Face faces[6] = {
        {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}},   {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}},
        {{1, 0, 0}, {0, 0, -1}, {0, 1, 0}},  {{-1, 0, 0}, {0, 0, 1}, {0, 1, 0}},
        {{0, 1, 0}, {1, 0, 0}, {0, 0, -1}},  {{0, -1, 0}, {1, 0, 0}, {0, 0, 1}},
    };
    for (const Face& f : faces) {
        uint32_t base = (uint32_t)m.verts.size();
        Vec3 c = f.n * 0.5f;
        const float sx[4] = {-1, 1, 1, -1}, sy[4] = {-1, -1, 1, 1};
        const float uu[4] = {0, 1, 1, 0}, vv[4] = {0, 0, 1, 1};
        for (int k = 0; k < 4; k++) {
            Vertex v;
            v.pos = c + f.u * (sx[k] * 0.5f) + f.v * (sy[k] * 0.5f);
            v.normal = f.n;
            v.u = uu[k];
            v.v = vv[k];
            m.verts.push_back(v);
        }
        const uint32_t ix[6] = {0, 1, 2, 0, 2, 3};
        for (uint32_t i : ix) m.idx.push_back(base + i);
    }
    m.finalize();
    return m;
}

inline Mesh makeSphere(int stacks, int slices) {
    Mesh m;
    for (int i = 0; i <= stacks; i++) {
        float th = kPi * (float)i / (float)stacks;
        for (int j = 0; j <= slices; j++) {
            float ph = 2.0f * kPi * (float)j / (float)slices;
            Vec3 n{std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph)};
            Vertex v;
            v.pos = n * 0.5f;
            v.normal = n;
            v.u = (float)j / (float)slices;
            v.v = (float)i / (float)stacks;
            m.verts.push_back(v);
        }
    }
    for (int i = 0; i < stacks; i++)
        for (int j = 0; j < slices; j++) {
            uint32_t A = (uint32_t)(i * (slices + 1) + j), B = A + (uint32_t)(slices + 1);
            uint32_t C = B + 1, D = A + 1;
            m.idx.insert(m.idx.end(), {A, C, B, A, D, C});
        }
    m.finalize();
    return m;
}

// Flat square on the XZ plane facing +Y, UVs repeat `uvRepeat` times.
inline Mesh makePlane(float size, float uvRepeat) {
    Mesh m;
    float h = size * 0.5f;
    const float xs[4] = {-h, h, h, -h}, zs[4] = {h, h, -h, -h};
    const float us[4] = {0, uvRepeat, uvRepeat, 0}, vs[4] = {0, 0, uvRepeat, uvRepeat};
    for (int k = 0; k < 4; k++) {
        Vertex v;
        v.pos = {xs[k], 0, zs[k]};
        v.normal = {0, 1, 0};
        v.u = us[k];
        v.v = vs[k];
        m.verts.push_back(v);
    }
    m.idx = {0, 1, 2, 0, 2, 3};
    m.finalize();
    return m;
}

inline Texture makeCheckerTexture() {
    Texture t;
    t.w = t.h = 64;
    t.px.resize(64 * 64);
    for (int y = 0; y < 64; y++)
        for (int x = 0; x < 64; x++) {
            bool a = ((x / 32) + (y / 32)) & 1;
            int c = a ? 235 : 170;
            if ((x % 32) == 0 || (y % 32) == 0) c = 110;
            t.px[(size_t)y * 64 + x] = ((uint32_t)c << 16) | ((uint32_t)c << 8) | (uint32_t)c;
        }
    return t;
}

inline Texture makeBrickTexture() {
    Texture t;
    t.w = t.h = 64;
    t.px.resize(64 * 64);
    for (int y = 0; y < 64; y++)
        for (int x = 0; x < 64; x++) {
            int row = y / 16;
            int xo = (x + (row & 1) * 16) % 32;
            bool mortar = (y % 16) < 2 || xo < 2;
            int noise = ((x * 7 + y * 13 + row * 31) % 23) - 11;
            int r = mortar ? 190 : 205 + noise, g = mortar ? 190 : 150 + noise, b = mortar ? 185 : 130 + noise;
            t.px[(size_t)y * 64 + x] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
        }
    return t;
}

struct SceneAssets {
    Mesh cube, sphereHi, sphereLo, floor;
    Texture checker, brick;
    SceneAssets() {
        cube = makeCube();
        sphereHi = makeSphere(8, 12);   // 192 triangles
        sphereLo = makeSphere(4, 6);    // 48 triangles
        floor = makePlane(300.0f, 150.0f);
        checker = makeCheckerTexture();
        brick = makeBrickTexture();
    }
};

// Floor plus gridN x gridN spinning cubes/spheres. gridN = 10 is roughly 10,000 triangles.
inline void buildDemoScene(const SceneAssets& a, int gridN, float time, std::vector<Instance>& out) {
    out.clear();
    Instance fl;
    fl.mesh = &a.floor;
    fl.tex = &a.checker;
    fl.tint = {0.45f, 0.7f, 0.45f};
    out.push_back(fl);
    const Vec3 palette[6] = {{1, 0.4f, 0.35f}, {0.4f, 0.7f, 1}, {1, 0.85f, 0.3f},
                             {0.6f, 1, 0.5f},  {0.9f, 0.5f, 1}, {1, 0.65f, 0.3f}};
    for (int i = 0; i < gridN; i++)
        for (int j = 0; j < gridN; j++) {
            Instance in;
            float x = ((float)i - (float)(gridN - 1) * 0.5f) * 3.2f;
            float z = ((float)j - (float)(gridN - 1) * 0.5f) * 3.2f;
            float y = 0.9f + 0.25f * std::sin(time * 2.0f + (float)(i + j));
            bool cube = ((i + j) & 1) == 0;
            in.model = translation({x, y, z}) * rotationY(time * 0.8f + (float)i * 0.3f) *
                       rotationX(time * 0.5f + (float)j * 0.2f) * scaling(1.4f);
            in.scale = 1.4f;
            in.mesh = cube ? &a.cube : &a.sphereHi;
            in.lodMesh = cube ? nullptr : &a.sphereLo;
            in.lodDistance = 22.0f;
            in.tex = cube ? &a.brick : &a.checker;
            in.tint = palette[(i * 3 + j) % 6];
            out.push_back(in);
        }
}

}  // namespace ce
