// Headless runner: --selftest, --bench [frames], --out file.ppm [--mode single|tiled] [--scale 0.5]
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <thread>

#include "renderer.h"
#include "scene.h"

using namespace ce;

static int g_fail = 0;
#define CHECK(cond, msg)                                   \
    do {                                                   \
        if (cond) std::printf("  PASS  %s\n", msg);        \
        else { std::printf("  FAIL  %s\n", msg); g_fail++; } \
    } while (0)

static uint64_t hashPixels(const Renderer& r) {
    uint64_t h = 1469598103934665603ull;
    size_t n = (size_t)r.width() * r.height();
    for (size_t i = 0; i < n; i++) { h ^= r.pixels()[i]; h *= 1099511628211ull; }
    return h;
}

static int windingViolations(const Mesh& m) {
    int bad = 0;
    for (size_t i = 0; i + 2 < m.idx.size(); i += 3) {
        const Vertex &a = m.verts[m.idx[i]], &b = m.verts[m.idx[i + 1]], &c = m.verts[m.idx[i + 2]];
        Vec3 n = cross(b.pos - a.pos, c.pos - a.pos);
        if (length(n) < 1e-6f) continue;  // zero-area triangles at sphere poles
        if (dot(n, a.normal) <= 0) bad++;
    }
    return bad;
}

static int selfTest() {
    std::printf("== self-test ==\n");
    // math
    Mat4 P = perspective(1.2f, 16.0f / 9.0f, 0.1f, 100.0f);
    auto ndcZ = [&](float zv) { float cz = P.m[2][2] * zv + P.m[2][3], cw = P.m[3][2] * zv; return cz / cw; };
    CHECK(std::fabs(ndcZ(-0.1f) + 1.0f) < 1e-4f, "projection maps near plane to ndc z = -1");
    CHECK(std::fabs(ndcZ(-100.0f) - 1.0f) < 1e-4f, "projection maps far plane to ndc z = +1");
    float halfW = std::tan(0.6f) * (16.0f / 9.0f);
    float nx = (P.m[0][0] * (halfW * 10.0f)) / (-P.m[3][2] * -10.0f * -1.0f);
    CHECK(std::fabs(std::fabs(nx) - 1.0f) < 1e-3f, "point on the right frustum edge maps to |ndc x| = 1");
    Mat4 I = Mat4::identity() * translation({1, 2, 3});
    Vec3 tp = transformPoint(I, {1, 1, 1});
    CHECK(tp.x == 2 && tp.y == 3 && tp.z == 4, "translation matrix moves points correctly");

    // mesh winding (counter-clockwise from outside)
    SceneAssets a;
    CHECK(windingViolations(a.cube) == 0, "cube triangles all wind counter-clockwise outward");
    CHECK(windingViolations(a.sphereHi) == 0, "sphere triangles all wind counter-clockwise outward");
    CHECK(windingViolations(a.floor) == 0, "floor triangles face up");

    RenderSettings base;
    base.shading = ShadeMode::Unlit;
    base.textures = false;
    Camera cam;
    cam.pos = {0, 0, 0};

    // coverage: a cube in front of the camera is visible, corners stay sky
    Renderer r;
    r.setTarget(320, 180, 1.0f);
    std::vector<Instance> empty, one;
    r.render(empty, cam, base);
    uint32_t skyCorner = r.pixels()[0], skyCenter = r.pixels()[(size_t)90 * 320 + 160];
    Instance cube;
    cube.mesh = &a.cube;
    cube.model = translation({0, 0, -4}) * scaling(2.0f);
    cube.scale = 2.0f;
    one.push_back(cube);
    r.render(one, cam, base);
    CHECK(r.pixels()[(size_t)90 * 320 + 160] != skyCenter, "cube covers the center pixel");
    CHECK(r.pixels()[0] == skyCorner, "corner pixel remains sky");
    CHECK(r.stats().trisDrawn == 2, "only the 2 camera-facing cube triangles are drawn (back-face culling)");

    // near-plane clipping: huge floor crossing the camera must not break
    std::vector<Instance> fl;
    Instance f;
    f.mesh = &a.floor;
    fl.push_back(f);
    Camera low = cam;
    low.pos = {0, 0.3f, 0};
    r.render(fl, low, base);
    CHECK(r.pixels()[(size_t)179 * 320 + 160] != skyCorner, "floor crossing the near plane is clipped and visible below the horizon");

    // threading: single-thread and 4-thread tiled output must be identical
    std::vector<Instance> demo;
    buildDemoScene(a, 8, 1.234f, demo);
    Camera dc;
    dc.pos = {0, 6, 22};
    dc.pitch = -0.2f;
    RenderSettings s1 = RenderSettings::preset(2), s4 = s1;
    s1.mode = RenderMode::SingleThread;
    s4.mode = RenderMode::TiledMultiThread;
    s4.threads = 4;
    Renderer r1, r4;
    r1.setTarget(640, 360, 1.0f);
    r4.setTarget(640, 360, 1.0f);
    r1.render(demo, dc, s1);
    r4.render(demo, dc, s4);
    CHECK(hashPixels(r1) == hashPixels(r4), "single-thread and 4-thread tiled renders are pixel-identical");

    // culling off vs on gives (almost) the same picture
    RenderSettings nc = s1;
    nc.backfaceCull = false;
    Renderer r5;
    r5.setTarget(640, 360, 1.0f);
    r5.render(demo, dc, nc);
    size_t diff = 0, n = (size_t)r1.width() * r1.height();
    for (size_t i = 0; i < n; i++) diff += (r1.pixels()[i] != r5.pixels()[i]);
    char buf[128];
    std::snprintf(buf, sizeof buf, "back-face culling does not change the image (%.3f%% pixels differ)", 100.0 * (double)diff / (double)n);
    CHECK((double)diff / (double)n < 0.01, buf);

    std::printf("== %s ==\n", g_fail ? "SOME TESTS FAILED" : "ALL TESTS PASSED");
    return g_fail ? 1 : 0;
}

static void writePPM(const Renderer& r, const char* path) {
    FILE* f = std::fopen(path, "wb");
    if (!f) { std::printf("cannot write %s\n", path); return; }
    std::fprintf(f, "P6\n%d %d\n255\n", r.width(), r.height());
    for (int y = 0; y < r.height(); y++)
        for (int x = 0; x < r.width(); x++) {
            uint32_t c = r.pixels()[(size_t)y * r.width() + x];
            unsigned char rgb[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c};
            std::fwrite(rgb, 1, 3, f);
        }
    std::fclose(f);
}

static double benchOne(const SceneAssets& a, int frames, RenderSettings s, int W, int H, Stats* last) {
    Renderer r;
    r.setTarget(W, H, s.resolutionScale);
    std::vector<Instance> scene;
    Camera cam;
    cam.pos = {0, 6, 22};
    cam.pitch = -0.2f;
    using clk = std::chrono::steady_clock;
    for (int i = 0; i < 3; i++) { buildDemoScene(a, 10, 0.1f * (float)i, scene); r.render(scene, cam, s); }
    auto t0 = clk::now();
    for (int i = 0; i < frames; i++) {
        buildDemoScene(a, 10, 0.05f * (float)i, scene);
        r.render(scene, cam, s);
    }
    double total = std::chrono::duration<double, std::milli>(clk::now() - t0).count();
    if (last) *last = r.stats();
    return total / frames;
}

int main(int argc, char** argv) {
    bool doTest = false, doBench = false;
    int frames = 30;
    const char* out = nullptr;
    RenderSettings s = RenderSettings::preset(2);
    for (int i = 1; i < argc; i++) {
        if (!std::strcmp(argv[i], "--selftest")) doTest = true;
        else if (!std::strcmp(argv[i], "--bench")) { doBench = true; if (i + 1 < argc && argv[i + 1][0] != '-') frames = std::atoi(argv[++i]); }
        else if (!std::strcmp(argv[i], "--out") && i + 1 < argc) out = argv[++i];
        else if (!std::strcmp(argv[i], "--mode") && i + 1 < argc) s.mode = !std::strcmp(argv[++i], "single") ? RenderMode::SingleThread : RenderMode::TiledMultiThread;
        else if (!std::strcmp(argv[i], "--scale") && i + 1 < argc) s.resolutionScale = (float)std::atof(argv[++i]);
        else if (!std::strcmp(argv[i], "--threads") && i + 1 < argc) s.threads = std::atoi(argv[++i]);
    }
    if (!doTest && !doBench && !out) {
        std::printf("This is the TEST tool, not the game. To play, run cpuengine.exe.\n\n");
        std::printf("usage: cpuengine_headless --selftest | --bench [frames] | --out frame.ppm [--mode single|tiled] [--scale 0.5] [--threads N]\n");
#ifdef _WIN32
        std::printf("\nPress Enter to close...\n");
        std::getchar();
#endif
        return 0;
    }
    int rc = 0;
    if (doTest) rc = selfTest();
    SceneAssets assets;
    if (out) {
        std::vector<Instance> scene;
        buildDemoScene(assets, 10, 1.0f, scene);
        Camera cam;
        cam.pos = {0, 6, 22};
        cam.pitch = -0.2f;
        Renderer r;
        r.setTarget(1280, 720, s.resolutionScale);
        r.render(scene, cam, s);
        writePPM(r, out);
        const Stats& st = r.stats();
        std::printf("wrote %s (%dx%d): %d tris drawn of %d submitted, %d/%d objects culled, %.2f ms, %d thread(s)\n",
                    out, r.width(), r.height(), st.trisDrawn, st.trisSubmitted, st.objectsCulled, st.objectsTotal, st.msTotal, st.threads);
    }
    if (doBench) {
        std::printf("== benchmark: 10x10 demo scene, 1280x720 window, %d frames each ==\n", frames);
        std::printf("hardware threads reported by the OS: %u\n", std::thread::hardware_concurrency());
        std::printf("%-34s %9s %8s %9s\n", "config", "ms/frame", "FPS", "tris");
        struct Cfg { const char* name; RenderMode mode; float scale; int preset; };
        const Cfg cfgs[] = {
            {"single-thread, 100% res, High", RenderMode::SingleThread, 1.0f, 2},
            {"tiled multi-thread, 100% res, High", RenderMode::TiledMultiThread, 1.0f, 2},
            {"tiled multi-thread, 75% res, Medium", RenderMode::TiledMultiThread, 0.75f, 1},
            {"tiled multi-thread, 50% res, Low", RenderMode::TiledMultiThread, 0.5f, 0},
        };
        for (const Cfg& c : cfgs) {
            RenderSettings cs = RenderSettings::preset(c.preset);
            cs.mode = c.mode;
            cs.resolutionScale = c.scale;
            Stats st;
            double ms = benchOne(assets, frames, cs, 1280, 720, &st);
            std::printf("%-34s %9.2f %8.1f %9d\n", c.name, ms, 1000.0 / ms, st.trisDrawn);
        }
    }
    return rc;
}
