@echo off
REM Builds cpuengine.exe on Windows. Works with Visual Studio (open "Developer Command Prompt") or MinGW-w64 (g++).
where cl >nul 2>nul
if %errorlevel%==0 (
  echo Using Visual Studio compiler...
  cl /nologo /std:c++17 /O2 /EHsc /MT /Fe:cpuengine.exe src\app_win32.cpp src\renderer.cpp /link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib winmm.lib
  cl /nologo /std:c++17 /O2 /EHsc /MT /Fe:cpuengine_headless.exe src\headless.cpp src\renderer.cpp
  goto done
)
where g++ >nul 2>nul
if %errorlevel%==0 (
  echo Using MinGW g++...
  g++ -std=c++17 -O2 -mwindows -static -static-libgcc -static-libstdc++ -pthread -o cpuengine.exe src\app_win32.cpp src\renderer.cpp -lwinmm -lgdi32 -luser32
  g++ -std=c++17 -O2 -static -pthread -o cpuengine_headless.exe src\headless.cpp src\renderer.cpp
  goto done
)
echo No compiler found. Install Visual Studio Build Tools or MSYS2 MinGW-w64, or use the GitHub Actions workflow in this folder.
exit /b 1
:done
echo Done. Run: cpuengine_headless.exe --selftest   then   cpuengine.exe
